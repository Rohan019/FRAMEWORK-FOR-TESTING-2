package Arrays;

public class Test1 {
	public static void main (String args[]) {
		
		int[] marks = new int [3];
		marks[0]=18;
		marks[1]=19;
		marks[2]=20;
		
		//System.out.println(marks[0]);
		//System.out.println(marks[1]);
		//System.out.println(marks[2]);
		
		for(int i=0; i<3 ; i++) {
			System.out.println(marks[i]);
		}
		
		
	}

}
