package basics;

public class Boxing {

	public static void main(String[] args) {
		int a = 90;
		System.out.println(a);
		
		Integer a1 = a;  //Autoboxing
		System.out.println(a1);
		System.out.println(a1.toString());
	}

}
 