package basics;

public class ExplicitBoxing {
	public static void main (String args[]) {
		int a = 345;
		Integer a1 = Integer.valueOf(a);  //Explicit boxing
		
		System.out.println(a1);
	}

}
