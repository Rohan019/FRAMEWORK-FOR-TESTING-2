package basics;
// print no from 1 to 10
public class PrintNo {
	
	public static void main(String args[]) {
		test(1);
			}
	public static void test(int n) {
		if(n<=10) {
			System.out.println(n);
			test(++n);
		}
	}

}
