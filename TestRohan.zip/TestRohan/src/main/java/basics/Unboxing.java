package basics;

public class Unboxing {
	public static void main(String[] args) {
		Integer a1=30;
		System.out.println(a1);
		
		int i = a1;    //Autoboxing
		System.out.println(i); 
		
	}

}
