package Strings;

public class Reverse3 {

	public static void main(String[] args) {
		String s1 = "ABCDEF";
		String s2 = "";
		
		for(int i=s1.length()-1; i>=1;i--)
		{
			s2=s2+s1.charAt(i);
		}
		System.out.println(s2);
	}

}
