package collection;

import java.util.HashSet;

public class HashSetdemo3 {

	public static void main(String[] args) {
		HashSet<Integer> h1 = new HashSet<Integer> ();
		
		h1.add(1);
		h1.add(2);
		h1.add(3);
		h1.add(4);
		h1.add(5);
		
		System.out.println("HashSet1:"+h1);
		
		HashSet<Integer> h2 = new HashSet<Integer> ();
	
		h2.add(3);
		h2.add(4);
		h2.add(5);
		
		System.out.println("HashSet2:"+h2);
		
		/*
		 * //Union h1.addAll(h2); System.out.println("Union:"+h1); //Union:[1, 2, 3, 4,
		 * 5]
		 * 
		 * //Intersection h1.retainAll(h2); System.out.println("Intersection:"+h2);//[3,
		 * 4, 5]
		 */		
		//difference
		h1.removeAll(h2);
		System.out.println("difference:"+h1);
		
		
	}

}
