package collection;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashTableDemo1 {

	public static void main(String[] args) {
		//Hashtable h1 = new Hashtable();
		//Hashtable h1 = new ( intital capacity);
		//Hashtable h1 = new Hashtable(intital capacity,load factor);
		Hashtable<Integer,String> h1 = new Hashtable<Integer,String> ();
		
		h1.put(101, "Rahul");
		h1.put(102, "rajes");
		h1.put(103, "Rohan");
		h1.put(104, "Raj");
		//h1.put(null, "x");  nullpointer exception
		//h1.put(107, null);  nullpointer exception
		
		System.out.println(h1);
		
		System.out.println(h1.get(103));  //Rohan
		
		h1.remove(102);
		System.out.println(h1); //{104=Raj, 103=Rohan, 101=Rahul}
		
		System.out.println(h1.containsKey(101));   //true
		System.out.println(h1.containsKey(108));   //false
		
		System.out.println(h1.isEmpty());      //false
		
		System.out.println(h1.keySet());   //[104, 103, 101]
		
		System.out.println(h1.values());    //[Raj, Rohan, Rahul]
		
		
		//read individual
		for(int k:h1.keySet()) {
			System.out.println(k+"   "+ h1.get(k));//104   Raj
													//103   Rohan
													//101   Rahul
		}
		
		
		System.out.println("=====================================================");
		
		for(Map.Entry entry:h1.entrySet()) {
			System.out.println(entry.getKey()+"="+entry.getValue());
		}
		
		//iterator
		
		Set s=h1.entrySet();
		
		Iterator i1=s.iterator();
		while(i1.hasNext()) {
			Map.Entry entry= (Entry) i1.next();
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
		
		
		
	}

}
