package collection;

import java.util.Iterator;
import java.util.LinkedList;

public class Linkedlistdemo1 {

	public static void main(String[] args) {
		// Declare LinkedList
		// LinkedList <String> l = new LinkedList <String>();  -- Homogenus
		
		LinkedList l = new LinkedList();  //Heterogenous
		l.add(1);
		l.add("Rohan");
		l.add("wassup");
		l.add(89);
		l.add(true);
		l.add(null);
		
		System.out.println(l);
		
		//remove
		l.remove(3);
		System.out.println("After removing element:"+l); //[1, Rohan, wassup, true, null]
		
		//Insert --  adding an element
		l.add(4, "Java");
		System.out.println("After Inserting element:"+l);//[1, Rohan, wassup, true, Java, null]
		
		//retrive
		System.out.println("Retrivng the element:"+l.get(2)); // wassup
		
		//Change the value
		l.set(0, 2);
		System.out.println("Adding a new value:"+l); //[2, Rohan, wassup, true, Java, null]
		
		//contains()
		System.out.println(l.contains("Java"));
		System.out.println(l.contains("Python"));
		
		//isEmpty()
		System.out.println(l.isEmpty());
		
		//Read the data
		//1. Using for loop
		System.out.println("-----------------------------------------------------------");
		System.out.println("Reading element using for loop");
		for(int i=0;i<l.size();i++) {
			System.out.println(l.get(i));
		}
		
		//2. For each loop
		System.out.println("-----------------------------------------------------------");
		System.out.println("Reading element using for each loop");
		for(Object r:l) {
			System.out.println(r);
		}
		
		//3. Iterator
		System.out.println("-----------------------------------------------------------");
		System.out.println("Reading element using Iterator");
		Iterator m =  l.iterator();
		while(m.hasNext()) {
			System.out.println(m.next());
		}

	}

}
