package collection;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListdemo2 {
	public static void main(String args[]) {
		ArrayList a1 = new ArrayList();
		
		a1.add("R");
		a1.add("0");
		a1.add("H");
		a1.add("A");
		a1.add("N");
		
		ArrayList a1_dup = new ArrayList();
		a1_dup.addAll(a1);
		System.out.println(a1_dup);    //[R, 0, H, A, N]
		
		a1_dup.removeAll(a1);
		System.out.println("After removing the elements"+a1_dup);  // []
		
		//sort  --- collections.sort()
		System.out.println("Element in arry list: "+a1);
		Collections.sort(a1);
		System.out.println("After sorting the elements: "+a1); //[0, A, H, N, R]
		
		//reverse elemet
		Collections.sort(a1,Collections.reverseOrder(null));
		System.out.println("Rversing the element: "+a1); //[R, N, H, A, 0]
		
		//Shuffeling the collection
		Collections.shuffle(a1);
		System.out.println("Shuffeling the elemets: "+a1);  //[0, A, R, H, N]
		
		
	}
}
