package collection;

import java.util.ArrayList;
import java.util.Arrays;

//Convert Array into ArrayList
public class ArrayListdemo3 {
	public static void main(String args[]) {
		 String arr[] = {"rohan","sanjay","preetam"};
		 
		 for(String value:arr) {
			 System.out.println(value);
		 }
		 
		 //converting array into arrayList
		 
		 ArrayList a1 = new ArrayList(Arrays.asList(arr));
		 System.out.println(a1);
		 
		 
	}

}
