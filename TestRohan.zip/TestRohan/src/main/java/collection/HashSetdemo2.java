package collection;

import java.util.HashSet;

public class HashSetdemo2 {
	public static void main(String args[]) {
		HashSet<Integer> evenno = new HashSet<Integer>();
		
		evenno.add(2);
		evenno.add(4);
		evenno.add(6);
		
		System.out.println(evenno);
		
		HashSet<Integer> number = new HashSet<Integer>();
		
		number.addAll(evenno);
		System.out.println(number);
		number.add(80);
		System.out.println(number);
		
		//remove
		number.removeAll(evenno);
		System.out.println(number);
		
		
	}

}
