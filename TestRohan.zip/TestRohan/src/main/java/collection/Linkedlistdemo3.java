package collection;

import java.util.LinkedList;

public class Linkedlistdemo3 {
	public static void main(String args[]) {
		LinkedList l = new LinkedList();
		l.add("car");
		l.add("train");
		l.add("bike");
		l.add("cycle");
	
		System.out.println(l);
		//add first or last element
		
		l.addFirst("rohan");
		System.out.println(l);
		
		l.addLast("darji");
		System.out.println(l);
		
		//get first or last element
		System.out.println(l.getFirst());
		System.out.println(l.getLast());
		
		//remove first and last element
		l.removeFirst();
		System.out.println(l);
		
		l.removeLast();
		System.out.println(l);
	}

}
