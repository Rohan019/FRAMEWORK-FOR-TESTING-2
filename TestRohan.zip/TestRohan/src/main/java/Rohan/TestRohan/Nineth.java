//Method overloading
package Rohan.TestRohan;

public class Nineth {
	void Nineth(){
		System.out.println("lets begin");
	}
	
	static void Nineth(int a, double b) {
		System.out.println("How its going");
	}
	
	void Nineth(char a, double b, int c){
		System.out.println("start the program");
	}
	
	void Nineth(int a){
		System.out.println("Processing");
	}
	
	static void Nineth(double a, char b) {
		System.out.println("the program is running");
	}
	
	public static void main (String args[]) {
		System.out.println("Main begins");
		Nineth(9,89.9);
		Nineth n1 = new Nineth();
		n1.Nineth(1);
		n1.Nineth();
		n1.Nineth('i',90.9,5);
		Nineth(45.4, 'r');
		
		
		
		
	}

}
