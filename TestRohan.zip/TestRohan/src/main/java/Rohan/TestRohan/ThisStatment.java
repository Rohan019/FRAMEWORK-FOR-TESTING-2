package Rohan.TestRohan;

public class ThisStatment {
	ThisStatment(){
		System.out.println("Lest goo");
	}
	
	ThisStatment(int a, double b){
		this();
		System.out.println("the program start");
	}
	
	ThisStatment(char a, double b){
		this(1,9.9);
		System.out.println("processing");
	}
	
	ThisStatment(int a){
		this('3', 9.0);
		System.out.println("managing");
	}
	public static void main (String args[]) {
		System.out.println("Mian begins");
		new ThisStatment(2);
		System.out.println("Main ends");
		
	}
	

}
