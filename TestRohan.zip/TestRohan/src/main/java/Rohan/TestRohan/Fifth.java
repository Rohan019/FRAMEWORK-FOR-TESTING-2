//Constructor Overloading
package Rohan.TestRohan;

public class Fifth {
	Fifth(int a){
		System.out.println("First constructor");
	}
	
	Fifth(int b, double a){
		System.out.println("Second constructor");
	}
	
	Fifth(char a, double d, int c){
		System.out.println("THird constructor");
	}
	
	public static void main(String args[]) {
		System.out.println("Main Begins");
		new Fifth('M', 10.5, 9);
		new Fifth(4);
		new Fifth(8, 8.90);
		
	}

}
