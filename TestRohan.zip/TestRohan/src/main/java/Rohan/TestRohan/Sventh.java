// this() calling statment in Java 
package Rohan.TestRohan;

public class Sventh {
	Sventh(){
		System.out.println("First statment");
	}
	
	Sventh(int a, int b){
		this();
		System.out.println("Second statment");
	}
	
	Sventh(char a,  double b, int c){
		this(12,3);
		System.out.println("Third statment");
	}
	
	public static void main (String args[]) {
		System.out.println("Main Begins");
		new Sventh('r',45.5, 9);
		System.out.println("Main Ends");
		
	}

}
