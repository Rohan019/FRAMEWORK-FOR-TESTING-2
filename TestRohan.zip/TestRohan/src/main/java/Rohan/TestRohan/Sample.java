package Rohan.TestRohan;

//How to create object and why ?

public class Sample {
	void dumb(){
		System.out.println("take this dumb");
	}
	static void gun() {
		System.out.println("take this sample");
	}
	public static void main (String args[]) {
		System.out.println("Run the program");
		gun();
		//Sample s1 = new Sample();
		//s1.dumb();
		 new Sample().dumb();
	}
	

}
