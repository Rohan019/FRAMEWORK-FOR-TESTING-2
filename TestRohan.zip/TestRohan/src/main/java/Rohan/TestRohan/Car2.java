// Getter and setter
package Rohan.TestRohan;

public class Car2 {
	private String Work;
	private String Name;
	private double Salary;
	
	public void setwork(String work) {
		this.Work = work;
	}
	public void setname(String Name) {
		this.Name = Name;
	}
	public void setsal(double Salary) {
		this.Salary = Salary; 
	}

	public static void main(String[] args) {
		System.out.println("Main begins");
		Car2 c1 = new Car2();
		c1.setwork("Software engineer");
		c1.setname("Rohan");
		c1.setsal(100000);
		
		System.out.println("workprofile is"+" "+c1.Work);
		System.out.println("The name is"+" "+ c1.Name);
		System.out.println("The salary is"+" "+ c1.Salary);
	}

}
