// Final Variable

package polymorphism;


public class Dsm {
	public static void main(String args[]) {
		final int a = 20; // final local variable
		//int a=50;                   --> Compile time error
		System.out.println("the value is"+" "+a);
		}

}
