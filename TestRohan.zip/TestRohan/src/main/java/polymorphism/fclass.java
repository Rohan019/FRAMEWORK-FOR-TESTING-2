//Final class 
//We can not inherit final class
//But we can create object for Final class
package polymorphism;

final class team{
	void order() {
		System.out.println("Please get my order");
	}
}

public class fclass {
	public static void main (String args[]) {
	team t1 = new team();
	t1.order();
	}
	

	
}
