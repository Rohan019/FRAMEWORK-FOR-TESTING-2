package polymorphism;

class demo{
	static int i = 20;
}

class demo1 extends demo{
	static int i = 10;
}

public class Test {

	public static void main(String[] args) {
		System.out.println("Main begins");
		
		demo1 d1 = new demo1();
		System.out.println(d1.i);
		
		demo d2 = new demo();
		System.out.println(d2.i);
		
		
		
		
		
	}

}
