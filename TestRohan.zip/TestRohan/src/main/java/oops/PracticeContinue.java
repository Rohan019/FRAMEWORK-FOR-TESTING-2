package oops;

public class PracticeContinue {

	public static void main(String[] args) {
		System.out.println("Main Begins");
		PracticeContinue p1 = new PracticeContinue();
		Practice p2 = new Practice();
		
		p2.setdep("QA");
		p2.setname("Rohan");
		p2.setage(25);
		p2.setsal(45.5);
		
		System.out.println("The role is "+" "+p2.getdepartment(null));
		System.out.println("The name is "+" "+p2.getname(null));
		System.out.println("The role is "+" "+p2.getage(0));
		System.out.println("The role is "+" "+p2.getsal(0));


	}

	

}
