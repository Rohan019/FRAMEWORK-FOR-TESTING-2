// method overriding
package inheritance;

class mkt{
	void field() {
		System.out.println("Super class");
	}
}

class mkt1 extends mkt{
	void field() {
		System.out.println("Lets start the progrm");
	}
	
}
public class MetOverding {
	
public static void main(String args[]) {
	
	System.out.println("Main begins");
	mkt1 m1 = new mkt1();
	m1.field();
}
}
