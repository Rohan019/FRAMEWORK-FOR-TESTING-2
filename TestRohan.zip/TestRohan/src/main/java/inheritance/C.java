package inheritance;

class A {
	 static int j = 20;
	 
	 static 
	 {
		 System.out.println("Lets goo");
	 }
}

class B extends A {
	static {
	System.out.println("main begins"); //lOADING PROCESS OF SUBCLASS IS OPTIONAL
	}
}

public class C {
public static void main (String args[]) {
	System.out.println("Program start");
	System.out.println(B.j);
	System.out.println();
	
}
}
