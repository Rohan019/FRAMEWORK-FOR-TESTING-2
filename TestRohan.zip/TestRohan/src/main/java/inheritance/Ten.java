//Multi Level Inheritance

package inheritance;

class eight{
	void field() {
		System.out.println("Super class");
	}
}

class nine extends eight {
	void dum() {
		System.out.println("Super class 2");
	}
}

public class Ten extends nine {
	public static void main (String args[]) {
		System.out.println("Main Begins");
		Ten t1 = new Ten();
		t1.dum();
		t1.field();
	}

}
