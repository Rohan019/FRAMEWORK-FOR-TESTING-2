package inheritance;

class Practicve{
	void field(){
		System.out.println("program begins");
		
	}
}


public class Demo extends Practicve {
	void dum() {
		System.out.println("Lets start the program");
	}
	
	public static void main(String args[]) {
		System.out.println("Main begins");
		Demo d1 = new Demo();
		d1.field();
		d1.dum();
		
	}
	 

}
