package capgemini_automation_testing.Selenium2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Assertionclass {

	@Test(enabled = false)
	public void testassert()
	{
		boolean actualvalue = false;
		try{
			Assert.assertTrue(actualvalue);
		}
		
		catch(Exception ex)
		{
			System.out.println("Test case is getting failed because my actual result is "+actualvalue+ex);
		}
		
		
		System.out.println("I am using assert true assertion ");
	}
	
	@Test
	public void testassert1()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\RSHERBAH\\Downloads\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		SoftAssert obj = new SoftAssert();
		
		try{
			driver.get("https://www.facebook.com/");
		
		String Actualtitle = driver.getTitle();
		String ExpectedTitle = "google";
		obj.assertEquals(Actualtitle, ExpectedTitle);
		
		
		//driver.findElement(By.xpath("//a[text()='English']")).click();
		}
		
		catch(Exception ex)
		{
			System.out.println("element is not found in facebook page"+ex);
			//Assert.fail();
		}
		
		
		
		System.out.println("my Execution is still going on");
		
		obj.assertAll();  // they will throw all the fail assertion
		
		
				
		
		
	}

	
	@Test(enabled = false)
	public void testassert2()
	{
		
	}
}
