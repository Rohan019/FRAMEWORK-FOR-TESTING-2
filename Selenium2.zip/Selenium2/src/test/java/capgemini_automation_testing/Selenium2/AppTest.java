package capgemini_automation_testing.Selenium2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AppTest {
    
  @Test
  public void shouldAnswerWithTrue() {
    assertTrue(true);
  }
}
