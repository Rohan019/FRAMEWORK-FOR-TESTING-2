package capgemini_automation_testing.Selenium2;

public class App {
  public static void main(String[] args) {
    System.out.println("Hello World!");
  }
}
