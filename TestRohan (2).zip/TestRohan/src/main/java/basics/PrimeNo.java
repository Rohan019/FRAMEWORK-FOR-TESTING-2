package basics;

import java.util.*;
public class PrimeNo {
	public static void main(String args[]) {
		System.out.println("Please enter the nuber");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		
		
		for(int i=2;i<n;i++) {
			if(n%2==0) {
				System.out.println("It is prime no");
			}
			else {
				System.out.println("It is not a prime no");
			}
			
		}
		
	}

}
