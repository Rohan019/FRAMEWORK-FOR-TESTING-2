package oops;

public class Practice {
	
	private String Department;
	private String Name;
	private int age;
	private double salary;
	
	
	//Setter method
	public void setdep(String Department) {
		this.Department = Department;
	}
	
	public void setname(String Name) {
		this.Name = Name;
	}
	
	public void setage(int age) {
		this.age = age;
	}
	
	public void setsal(Double salary) {
		this.salary = salary;
	}
	
	//Getter method
	public String getdepartment(String Department) {
		return this.Department;
	}
	
	public String getname(String Name) {
		return this.Name;
	}
	
	
	public int getage(int age) {
		return this.age;
	}
	
	public double getsal(double salary) {
		return this.salary;
	}

	
	
	
	

}
