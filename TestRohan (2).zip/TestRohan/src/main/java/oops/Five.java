//Method Overloading

package oops;

class Five{
	public void m1() {
		System.out.println("No args");
	}
	
	public void m1(int i) {
		System.out.println("With args");;
	}



	public static void main(String args[]) {
		Five t1 = new Five();
		t1.m1();
		t1.m1(99);
	}

}
