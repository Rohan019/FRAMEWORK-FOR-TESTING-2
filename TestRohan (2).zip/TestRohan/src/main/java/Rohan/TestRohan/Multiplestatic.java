package Rohan.TestRohan;

public class Multiplestatic {
	public static void main(String args[]) {
		System.out.println("Start the program");
		two();
		three();
	}
	
	static void two() {
		System.out.println("Processing");
		
	}
	
	static void three() {
		System.out.println("Stop the program");
	}

}
