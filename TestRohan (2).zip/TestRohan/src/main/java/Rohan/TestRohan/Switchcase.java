package Rohan.TestRohan;
import java.util.*;
public class Switchcase {
	public static void main(String args[]) {
	Scanner sc = new Scanner(System.in);
	int button = sc.nextInt();
	
	switch(button) {
	case 1: System.out.println("a");
	break;
	case 2: System.out.println("b");
	break;
	case 3: System.out.println("c");
	break;
	default: System.out.println("invalid");
	
	
	}
	}

}
