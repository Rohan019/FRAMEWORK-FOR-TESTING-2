//Learning Constructor
package Rohan.TestRohan;

public class Constructor {
	
	Constructor(){
		System.out.println("Lets get started");
	}
	
	public static void main (String args[]) {
		System.out.println("It is software testing");
		new Constructor();
	}

}
