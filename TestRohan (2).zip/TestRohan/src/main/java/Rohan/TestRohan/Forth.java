//Learning about static and non static variables in a main method
package Rohan.TestRohan;

public class Forth {
	static int a = 10;
	double b = 0.01;
	
	void dumb() {
		System.out.println("This is dumb");
	}
	
	static void def() {
		System.out.println("This is def");
	}
	
	public static void main (String args[]) {
		System.out.println("It is software testing");
		def();
		Forth f1 = new Forth();
		f1.dumb();
		System.out.println(a);
		f1.b = 10;
		System.out.println(f1.b);
	}
	

}
