
//Getter and setter method

package Rohan.TestRohan;

public class Car {
	private int cost;
	private String name ;
	private double salary ;
	
	public void setcar(int cost) {
		this.cost = cost;
	}
	
	public void setname(String name) {
		this.name = name;
	}
	
	public void setname(double salary) {
		this.salary = salary;
	}
	
	public int getcar(int a) {
		
		return this.cost;
	}
	
	public String getname(String name) {
		return this.name;
	}
	
	public double getsal(double slalary) {
		return this.salary;
	}
	
	public static void main(String[] args) {
		System.out.println("MB");
		Car c1 = new Car();
		c1.setcar(9000);
		c1.setname("Rahul");
		c1.getsal(900000);
		
		System.out.println("the cost is"+c1.cost);
		System.out.println("the name is"+c1.name);
		System.out.println("the salary is"+c1.salary);
		
		

	}
	
	

}
