package collection;

import java.util.Collections;
import java.util.LinkedList;

public class Linkedlistdeo2 {
	public static void main(String args[]) {
		
		LinkedList l = new LinkedList();
		l.add("r");
		l.add("o");
		l.add("h");
		l.add("a");
		l.add("n");
		
		LinkedList l1 = new LinkedList();
		l1.addAll(l);
		System.out.println(l);
		
		//Remove all elements
		l1.removeAll(l);
		System.out.println(l1);
		
		//Sorting
		System.out.println("Before sorting:"+l);
		Collections.sort(l);
		System.out.println("After sorting:"+l);
		
		//reverse
		Collections.sort(l,Collections.reverseOrder());
		System.out.println("Reverse order:"+l);
	}

}
