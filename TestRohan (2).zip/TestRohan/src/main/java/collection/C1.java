package collection;

import java.util.ArrayList;
import java.util.Iterator;

public class C1 {
	public static void main(String args[]) {
		//ArrayList<String> a = new ArrayList<String>();  -- store homogenous value
		ArrayList a = new ArrayList();    // store hetrogenous value
		
		a.add(4);
		a.add(23);
		a.add(23);
		a.add("Rohan");
		a.add(23.09);
		a.add("low");
		a.add(null);
		
		System.out.println(a);
		
		//to know the size of the object
		System.out.println(a.size());
		
		//remove some obj or element
		a.remove("low");
		a.remove(2);
		System.out.println(a);
		
		//insert an new obj or element
		a.add(2, "Python");
		System.out.println(a);
		
		//retrive specific elements
		System.out.println(a.get(4));
		
		//change element or replace
		a.set(1, 90);
		System.out.println(a);  // [4, 90, Python, Rohan, 23.09, null]
		
		//Search --- contains -- It gives true/false
		System.out.println(a.contains(23));  // false
		System.out.println(a.contains("Python"));  //true
		
		//read the data
		//1. For loop
		/*
		 * System.out.println("Reading element using for loop");
		 * 
		 * for(int i=0;i<=a.size();i++) { System.out.println(a.get(i)); }
		 */
		
		//2. For each loop
		System.out.println("Reading element usig for each loop");
		for (Object e:a) {
			System.out.println(e);
		}
		
		//3. Iterator method
		System.out.println("Reading element using Iterator method");
		
		Iterator m = a.iterator();
		while(m.hasNext()) {
		System.out.println(m.next());
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
