package collection;

import java.util.HashSet;

public class HashSetdemo1{

	public static void main(String[] args) {
		//HashSet hs = new HashSet(100,(float)0.97); -------- size and load factor
				HashSet hs = new HashSet();
				
				hs.add("rohan");
				hs.add("A");
				hs.add(45);
				hs.add(null);
				hs.add(true);
				
				System.out.println(hs);
				
				//remove()
				hs.remove(null);
				System.out.println(hs);
				
				//contains
				System.out.println("this is element is present:"+hs.contains("Welcome"));
				System.out.println("this is element is present:"+hs.contains("rohan"));
				
				System.out.println("this is element is empty:"+hs.isEmpty());
				
				//reading
				for(Object e:hs) {
					System.out.println();
					System.out.println(e);
				}
	}
}