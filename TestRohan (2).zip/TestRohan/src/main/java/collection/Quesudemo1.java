package collection;

import java.util.PriorityQueue;

public class Quesudemo1 {
	public static void main(String args[]) {
		PriorityQueue q1 = new PriorityQueue();
		
		//add
		
		q1.add(1);
		q1.add(2);	
		q1.add(3);	
		q1.add(4);
		q1.add(5);	
		q1.offer(6);
		
		System.out.println(q1);
		
		//get head element
		
		System.out.println(q1.element());
		System.out.println(q1.peek());
		
		//return and remove element
		
		//System.out.println(q1.remove());
		//System.out.println(q1);
		
		System.out.println(q1.poll());
		System.out.println(q1);
		
	}

}
