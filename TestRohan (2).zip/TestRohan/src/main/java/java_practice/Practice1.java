package java_practice;

public class Practice1 {
	public static void main(String args[]) {
		//do concat the string
		
		String s1="java";
		String s2="maven";
		String s3="test";
		
		//System.out.println(s1+s2+s3);
		
		s1.concat(s2).concat(s3);
		
	}

}
