//Final Method

package polymorphism;

class eat{
	final public void order() {
		System.out.println("Where is my order");
	}
}

/*class ate extends eat{
	void order() {
		System.out.println("I have eaten");   //CTE
	}	*/	


public class fmethod {
	public static void main(String args[]) {
		eat e1 = new eat();
		e1.order();
	}
}
