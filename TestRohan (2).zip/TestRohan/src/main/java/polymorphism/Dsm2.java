// final (global variable)
package polymorphism;

public class Dsm2 {
	final static long a = 8900;
	public static void main (String args[]) {
		System.out.println(a);
		long a = 90; // CTE
	}

}
