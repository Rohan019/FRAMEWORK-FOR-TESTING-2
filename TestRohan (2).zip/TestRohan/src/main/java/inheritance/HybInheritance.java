//Hybrid level Inheritan

package inheritance;

class one{
	void play() {
		System.out.println("Lets playy");
	}
}

class two extends one{
	void study(){
		System.out.println("lets study");
	}
}

class three extends two{
	void field() {
		System.out.println("We are on the field");
	}
}

public class HybInheritance extends one {
	void dum() {
		System.out.println("Non static method");
	}
	
	public static void main(String args[]) {
		System.out.println("Main begins");
		HybInheritance h1 = new HybInheritance();
		h1.dum();
		h1.play();
		three t1 = new three();
		t1.field();
		t1.play();
		t1.study();
		
		
	}
}
