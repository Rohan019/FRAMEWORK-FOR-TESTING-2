//Super calling statment with non parametrized constructor
package inheritance;

class Esh{   
	
	Esh(){ 
		System.out.println("Super calling statment");  //constructor
	}
}

class Dsh extends Esh{
	 Dsh() {
		//super(); 
		System.out.println("Lets start the program");  //constructor
	}
}


class Rise extends Dsh{
	 Rise() {
		//super();
		System.out.println("pricessing"); //constructor
	}
}

public class SuperNonPara  {
	
	public static void main (String args[]) {
		System.out.println("Main begins");
		new Rise();
	}

}
