package inheritance;

class driver2 {
	static int j = 50;
	
	static {
		System.out.println("lets gooo");
	}
	
	static void fun() {
		System.out.println("Super class begins");
	}
	
}

class driver3 extends driver2{
	static void dum() {
		System.out.println("sub class begins");
	}
}

public class Driver {
	public static void main(String[] args) {
		System.out.println("Start the program");
		driver3.fun();
		driver3.dum();
		System.out.println(driver3.j);
		
		
		
		
		
	
	}

}
