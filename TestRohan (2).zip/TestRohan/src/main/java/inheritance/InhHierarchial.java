//Hierarchical Inheritance

package inheritance;

class Help{
	void man() {
		System.out.println("Super class that is Patent class");
	}
	
}

class Field extends Help{
	void run() {
		System.out.println("this is my sub class");
	}
}
 class InhHierarchial extends Help {
	void play() {
		System.out.println("Let start to program");
	}
	public static void main (String args[]) {
		System.out.println("Main Begins");
		InhHierarchial h1 = new InhHierarchial();
		h1.play();
		Field f1 = new Field();
		f1.run();
		h1.man();
		
	}

}
