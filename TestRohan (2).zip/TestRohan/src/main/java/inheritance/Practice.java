package inheritance;

class P1{
	int i = 90;
	{
		System.out.println("the prg get start");
	}
}

class P2 extends P1{
	int j = 20;
	 {
		System.out.println("Main begins");
	}
}

public class Practice {
	public static void main (String args[]) {
		System.out.println("Lets goo");
		P2 ref = new P2();
		System.out.println(ref.i);
		System.out.println(ref.j);
		
		
		
	}

	

}
