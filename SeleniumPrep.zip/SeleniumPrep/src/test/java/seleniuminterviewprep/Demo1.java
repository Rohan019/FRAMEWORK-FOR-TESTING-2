package seleniuminterviewprep;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class Demo1 {
	// Open the first browser in normal mode
    WebDriver driver = new ChromeDriver();
    driver.get("https://www.xyz.com"); // Replace with your desired URL
    String title = driver.getTitle();
    System.out.println("Title of the first browser: " + title);

    // Open the second browser in incognito mode
    ChromeOptions options = new ChromeOptions();
    options.addArguments("--incognito");
    WebDriver incognitoDriver = new ChromeDriver(options);
    incognitoDriver.get("https://www.xyz.com"); 

    incognitoDriver.findElement(By.tagName("body")).sendKeys(title); // Assuming you want to paste the title in the body

    // Switch back to the first browser
    incognitoDriver.quit();
    driver.switchTo().window(driver.getWindowHandle());

    // Close the first browser
    driver.quit();

}
y