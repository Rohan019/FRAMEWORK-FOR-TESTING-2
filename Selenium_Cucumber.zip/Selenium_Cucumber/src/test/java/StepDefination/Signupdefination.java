package StepDefination;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;

//import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hook.Hook;

public class Signupdefination {
WebDriver driver = Hook.driver;
	
	/*
	 * @Given("User is on the elearning application") public void
	 * user_is_on_the_elearning_application() { // Write code here that turns the
	 * phrase above into concrete actions String title = driver.getTitle();
	 * System.out.println(title);
	 * 
	 * }
	 */

	/*
	 * @When("User clicks on the signup page to register") public void
	 * user_clicks_on_the_signup_page_to_register() { // Write code here that turns
	 * the phrase above into concrete actions try {
	 * driver.findElement(By.xpath("//a[text()=' Sign up! ']")).click(); }
	 * catch(Exception e) {
	 * System.out.println("Not able to click on the signup button"+e); }
	 * 
	 * }
	 */

	/*
	 * @When("User is navigated to the registration page") public void
	 * user_is_navigated_to_the_registration_page() { // Write code here that turns
	 * the phrase above into concrete actions try { Thread.sleep(3000); String
	 * expectedtitle = "My Organization - My education - Registration"; String
	 * actualtitle = driver.getTitle();
	 * Assert.assertEquals(expectedtitle,actualtitle);
	 * System.out.println("You are able  to navigate to the registration page");
	 * 
	 * } catch(Exception e) {
	 * System.out.println("Not able to navigate to the registration page"+e);
	 * Assert.fail(); }
	 * 
	 * }
	 */
	    

	/*
	 * @Then("User enters mandatory details for registration like {string} and {string} and {string} and {string} and {string} and {string}"
	 * ) public void
	 * user_enters_mandatory_details_for_registration_like_and_and_and_and_and(
	 * String string, String string2, String string3, String string4, String
	 * string5, String string6) { // Write code here that turns the phrase above
	 * into concrete actions try {
	 * driver.findElement(By.id("registration_firstname")).sendKeys("Swadha");
	 * driver.findElement(By.id("registration_lastname")).sendKeys("Das");
	 * driver.findElement(By.id("registration_email")).sendKeys("swadha7@gmail.com")
	 * ; driver.findElement(By.id("username")).sendKeys("singh0007");
	 * driver.findElement(By.id("pass1")).sendKeys("Swadha@9707");
	 * driver.findElement(By.id("pass2")).sendKeys("Swadha@9707"); } catch(Exception
	 * e) { System.out.println("Not Able to enter the mandatory "+e); }
	 * 
	 * }
	 */

	/*
	 * @Then("user clicks on the register button") public void
	 * user_clicks_on_the_register_button() { // Write code here that turns the
	 * phrase above into concrete actions try {
	 * driver.findElement(By.id("registration_submit")).click();
	 * 
	 * } catch(Exception e) {
	 * System.out.println("Not able to click on registration button"+e); }
	 * 
	 * }
	 */
	
	@Given("User is on the elearning application page")
	public void user_is_on_the_elearning_application_page() {
	    // Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		System.out.println(title);
	   
	}

	@When("User enters the login credentials like {string} and {string}")
	public void user_enters_the_login_credentials_like_and(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			driver.findElement(By.id("login")).sendKeys("singh0007");
			driver.findElement(By.id("password")).sendKeys("Swadha@9707");
		}
		catch(Exception e)
		{
			System.out.println("Not Able to enter the login details "+e);
		}
	    
	}

	@Then("User clicks on the login button")
	public void user_clicks_on_the_login_button() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			driver.findElement(By.id("form-login_submitAuth")).click();
			
		}
		catch(Exception e) {
			System.out.println("Not able to click on login button"+e);
		}
		
	   
	}

	@Then("User is navigated to the welcome page")
	public void user_is_navigated_to_the_welcome_page() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			Thread.sleep(3000);
			String expectedtitle = "My Organization - My education - My courses";
			String actualtitle = driver.getTitle();
			Assert.assertEquals(expectedtitle,actualtitle);
			System.out.println("You are able  to navigate to the welcome page");
			
		}
		catch(Exception e)
		{
			System.out.println("Not able to navigate to the welcome page"+e);
			Assert.fail();
		}
	    
	}

	@Then("User enters on compose to send the message")
	public void user_enters_on_compose_to_send_the_message() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			driver.findElement(By.xpath("//a[text()='Compose']")).click();
			System.out.println("You are able to click on the compose button");
		}
		catch(Exception e) {
			System.out.println("Not able to click on the compose button"+e);
		}
		
	}

	@Then("User is navigated to the message page")
	public void user_is_navigated_to_the_message_page() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			Thread.sleep(3000);
			String expectedtitle = "My Organization - My education - Compose message";
			String actualtitle = driver.getTitle();
			Assert.assertEquals(expectedtitle,actualtitle);
			System.out.println("You are able  to navigate to the message page");
			
		}
		catch(Exception e)
		{
			System.out.println("Not able to navigate to the message page"+e);
			Assert.fail();
		}
		
	   
	}

	@Then("User clicks on Send field and type the name or select from dropdown and user enters the subject and user enters the message to be sent")
	public void user_clicks_on_Send_field_and_type_the_name_or_select_from_dropdown_and_user_enters_the_subject_and_user_enters_the_message_to_be_sent() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			driver.findElement(By.xpath("//*[@class='select2-search__field']")).sendKeys("virat");
			Thread.sleep(3000);
			driver.findElement(By.xpath("//li[contains(text(),'virat kohli (virat)')]")).click();
			driver.findElement(By.xpath("//*[@name='title']")).sendKeys("Regarding course details");
			System.out.println("Able to enter the fields ");

		}
		catch(Exception e)
		{
			System.out.println("Not Able to enter the fields "+e);
		}
		
	    
	}

	@Then("User clicks on the Send button")
	public void user_clicks_on_the_Send_button() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			driver.findElement(By.id("compose_message_compose")).click();
			
		}
		catch(Exception e) {
			System.out.println("Not able to click on submit button"+e);
		}
		
	   
	}

	@Then("the message sent is verified.")
	public void the_message_sent_is_verified() {
	    // Write code here that turns the phrase above into concrete actions
		try
		{
			Thread.sleep(3000);
			String expectedtitle = "My Organization - My education";
			String actualtitle = driver.getTitle();
			Assert.assertEquals(expectedtitle,actualtitle);
			System.out.println("You are able  to navigate to the message page confirmation");
			
		}
		catch(Exception e)
		{
			System.out.println("Not able to navigate to the message page confirmation"+e);
			Assert.fail();
		}
		
		
	    
	}
	


}
